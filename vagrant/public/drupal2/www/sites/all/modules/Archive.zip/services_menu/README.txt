
-- SUMMARY --

The menu service module.

For a full description of the module, visit the project page:
http://drupal.org/project/services_menu

To submit bug reports and feature suggestions, or to track changes:
http://drupal.org/project/issues/1199250

-- REQUIREMENTS --

Services module version 3.x 

-- INSTALLATION --

* Install as usual, see http://drupal.org/node/70151 for further information.